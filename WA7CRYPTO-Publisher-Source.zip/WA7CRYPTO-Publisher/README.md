# WA7CRYPTO Publisher (Android + private publisher service)

A private Android WebView shell and Node.js service for publishing text, up to four images, or one video to Binance Square through Binance's official `square-post` skill scripts.

## Important architecture and security

- The Android app does **not** contain the Binance Square API key.
- The Binance API key is stored only as an environment variable on the private publisher server (`BINANCE_SQUARE_OPENAPI_KEY`).
- A separate private app access token (`WA7_APP_TOKEN`) protects the publishing endpoint; the app sends it in an HTTPS Authorization header.
- Serve the backend over HTTPS. Do not expose it publicly without authentication/access controls; this starter service should be placed behind a private access gateway or extended with app authentication before production use.
- The official Binance skill currently documents text, up to 4 images, articles with a cover, and video publishing. This app starter implements text, image posts, and video posts. Article title/cover workflow can be added as a separate UI flow.
- Images and video cannot be attached to the same post. Video processing requires `ffmpeg`/`ffprobe` on the server.

## Android project

Open `android/` in Android Studio (JDK 17 recommended; Android SDK 35). Build using **Build > Build Bundle(s) / APK(s) > Build APK(s)**. The resulting debug APK is normally at `android/app/build/outputs/apk/debug/app-debug.apk`.

The current build environment used to prepare this source did not have Android SDK/Gradle installed, so no compiled APK is included yet. A GitHub Actions workflow is included at `.github/workflows/build-apk.yml`; after uploading this folder to a GitHub repository, run the **Build WA7CRYPTO APK** workflow and download the APK from its Artifacts section.

## Publisher server setup

1. Install Node.js 18+ and `ffmpeg` (which includes `ffprobe`) on a private HTTPS server.
2. Install the official Binance skill following its current instructions: https://www.binance.com/en/skills/detail/binance/square-post
3. Install backend dependencies: `cd backend && npm install`.
4. Set environment variables on the server:
   - `BINANCE_SQUARE_OPENAPI_KEY` = your Square posting key (never commit it)
   - `SQUARE_SKILL_DIR` = absolute path to the installed official skill folder (the folder containing `scripts/`)
   - `WA7_APP_TOKEN` = a long, random private token used only by this app
   - `PORT` = `8787` (optional)
5. Start: `npm start`.
6. Put the service behind HTTPS and a private network/access gateway where possible. The app token is a basic access control layer, not a substitute for a hardened production identity system.
7. Enter the HTTPS server URL in the app.

Create the Square posting key from Binance Square Creator Center: https://www.binance.com/square/creator-center/home

## Supported API

- `GET /health`
- `POST /api/publish` multipart fields:
  - `text`: post caption/body
  - `images`: 0–4 image files, or
  - `video`: one video file

The service calls the official Binance skill scripts instead of reimplementing Binance's media upload/polling protocol.

## Before production

This is a starter project, not a production-hardened deployment. Add request rate limits, strict MIME/type validation, audit logging that excludes secrets, and a secure deployment. Do not expose the service to the public internet without additional protections.

import express from 'express';
import multer from 'multer';
import helmet from 'helmet';
import cors from 'cors';
import { spawn } from 'node:child_process';
import { mkdtemp, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import path from 'node:path';

const app = express();
app.use(helmet({ crossOriginResourcePolicy: { policy: 'cross-origin' } }));
app.use(cors({ origin: true, allowedHeaders: ['Content-Type', 'Authorization'], methods: ['GET', 'POST', 'OPTIONS'] }));
const upload = multer({ dest: tmpdir(), limits: { fileSize: 500 * 1024 * 1024, files: 4 } });
const PORT = Number(process.env.PORT || 8787);
const KEY = process.env.BINANCE_SQUARE_OPENAPI_KEY;
const SKILL_DIR = process.env.SQUARE_SKILL_DIR;
const APP_TOKEN = process.env.WA7_APP_TOKEN;

app.get('/health', (_req, res) => res.json({ ok: true, service: 'WA7CRYPTO Publisher' }));
function runScript(script, args) {
  return new Promise((resolve, reject) => {
    const child = spawn(process.env.NODE_BIN || 'node', [path.join(SKILL_DIR, 'scripts', script), ...args], {
      env: { ...process.env, BINANCE_SQUARE_OPENAPI_KEY: KEY },
      stdio: ['ignore', 'pipe', 'pipe']
    });
    let stdout = '', stderr = '';
    child.stdout.on('data', d => stdout += d.toString());
    child.stderr.on('data', d => stderr += d.toString());
    child.on('error', reject);
    child.on('close', code => code === 0 ? resolve(stdout + '\n' + stderr) : reject(new Error((stderr || stdout || `Publisher exited ${code}`).slice(-3500))));
  });
}
app.post('/api/publish', (req, res, next) => {
  if (!APP_TOKEN) return res.status(503).json({ success: false, error: 'Private app access token is not configured on the server.' });
  const auth = req.headers.authorization || '';
  if (auth !== `Bearer ${APP_TOKEN}`) return res.status(401).json({ success: false, error: 'Unauthorized app access.' });
  next();
}, upload.fields([{ name: 'images', maxCount: 4 }, { name: 'video', maxCount: 1 }]), async (req, res) => {
  const files = [...(req.files?.images || []), ...(req.files?.video || [])];
  try {
    if (!KEY || !SKILL_DIR) return res.status(503).json({ success: false, error: 'Publisher is not configured. Set Binance Square API key and official skill directory on the server.' });
    const text = String(req.body?.text || '');
    const imgs = req.files?.images || [];
    const vids = req.files?.video || [];
    if (imgs.length && vids.length) return res.status(400).json({ success: false, error: 'Images and video cannot be combined.' });
    if (imgs.length > 4 || vids.length > 1) return res.status(400).json({ success: false, error: 'Maximum 4 images or 1 video.' });
    if (!text.trim() && !imgs.length && !vids.length) return res.status(400).json({ success: false, error: 'Post is empty.' });
    let output;
    if (vids.length) {
      const durationOut = await new Promise((resolve, reject) => {
        const p = spawn('ffprobe', ['-v','error','-show_entries','format=duration','-of','default=noprint_wrappers=1:nokey=1',vids[0].path]);
        let out=''; p.stdout.on('data',d=>out+=d); p.on('close',c=>c===0?resolve(out.trim()):reject(new Error('Could not read video duration; ffprobe is required.')));
      });
      output = await runScript('post-video.mjs', ['--video', vids[0].path, '--duration', durationOut, ...(text.trim() ? ['--text', text] : [])]);
    } else if (imgs.length) {
      output = await runScript('post-image.mjs', ['--text', text, '--images', imgs.map(f => f.path).join(',')]);
    } else {
      output = await runScript('post-text.mjs', ['--text', text]);
    }
    const url = output.match(/https?:\/\/\S+/)?.[0] || null;
    const postId = output.match(/\bID:\s*([A-Za-z0-9_-]+)/)?.[1] || null;
    res.json({ success: true, postId, url, message: 'Published', details: output.slice(-1200) });
  } catch (err) {
    res.status(502).json({ success: false, error: err.message || 'Publish failed' });
  } finally {
    await Promise.all(files.map(f => rm(f.path, { force: true }).catch(() => {})));
  }
});
app.listen(PORT, '0.0.0.0', () => console.log(`WA7CRYPTO Publisher listening on ${PORT}`));
